# react-holygrail
React Holy Grail - State of each column shared with the rest
